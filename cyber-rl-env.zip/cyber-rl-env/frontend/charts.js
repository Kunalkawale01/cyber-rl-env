let dataPoints = [];

const chart1 = new Chart(document.getElementById('chart'), {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            label: 'Attack Intensity',
            data: [],
            borderColor: 'cyan'
        }]
    }
});

const chart2 = new Chart(document.getElementById('chart2'), {
    type: 'bar',
    data: {
        labels: ["Low", "Medium", "High"],
        datasets: [{
            label: 'Distribution',
            data: [0, 0, 0],
            backgroundColor: ['green', 'orange', 'red']
        }]
    }
});

function updateUI(intensity, lat, lon) {
    dataPoints.push(intensity);
    if (dataPoints.length > 20) dataPoints.shift();

    chart1.data.labels = dataPoints.map((_, i) => i);
    chart1.data.datasets[0].data = dataPoints;

    let low = dataPoints.filter(x => x <= 4).length;
    let med = dataPoints.filter(x => x <= 7 && x > 4).length;
    let high = dataPoints.filter(x => x > 7).length;

    chart2.data.datasets[0].data = [low, med, high];

    chart1.update();
    chart2.update();

    // Alerts
    const alert = document.getElementById("alert");
    const status = document.getElementById("statusBar");
    const ai = document.getElementById("ai");

    if (intensity > 7) {
        alert.innerText = "🚨 HIGH ATTACK!";
        alert.style.color = "red";
        status.style.background = "red";
        status.innerText = "🔴 Under Attack";
        ai.innerText = "Block IP & increase firewall";
    } else if (intensity > 4) {
        alert.innerText = "⚠️ Medium Threat";
        alert.style.color = "orange";
        status.style.background = "orange";
        status.innerText = "🟠 Suspicious Activity";
        ai.innerText = "Monitor traffic";
    } else {
        alert.innerText = "✅ Safe";
        alert.style.color = "lime";
        status.style.background = "green";
        status.innerText = "🟢 Secure";
        ai.innerText = "System stable";
    }

    // Logs
    const logs = document.getElementById("logs");
    const li = document.createElement("li");
    li.innerText = `Attack (${lat.toFixed(2)}, ${lon.toFixed(2)}) → ${intensity}`;
    logs.prepend(li);

    if (logs.children.length > 20) logs.removeChild(logs.lastChild);
}
