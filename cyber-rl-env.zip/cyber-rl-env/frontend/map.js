const map = L.map('map').setView([20, 0], 2);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
}).addTo(map);

const ws = new WebSocket("ws://127.0.0.1:8000/ws");

ws.onmessage = (event) => {
    const data = JSON.parse(event.data);

    const lat = data.location[0];
    const lon = data.location[1];
    const intensity = data.intensity;

    const color = intensity > 7 ? "red" : intensity > 4 ? "orange" : "green";

    L.circleMarker([lat, lon], {
        color: color,
        radius: 8
    }).addTo(map);

    updateUI(intensity, lat, lon);
};
