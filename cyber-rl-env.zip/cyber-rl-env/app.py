import os
import sys

BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, WebSocket
from websocket import attack_stream

app = FastAPI()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await attack_stream(websocket)

@app.get("/")
def home():
    return {"message": "Cyber RL Backend Running 🚀"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7860)