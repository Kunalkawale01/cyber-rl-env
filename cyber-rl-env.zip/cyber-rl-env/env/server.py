from fastapi import FastAPI, WebSocket
import asyncio
from env.environment import CyberDefenseEnv

app = FastAPI()
env = CyberDefenseEnv()

@app.get("/")
def root():
    return {"message": "Cyber Defense Environment Running"}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()

    while True:
        data = env.step()
        await websocket.send_json(data)
        await asyncio.sleep(1)
