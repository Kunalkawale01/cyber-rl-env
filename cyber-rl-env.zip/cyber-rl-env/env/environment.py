import random

class CyberDefenseEnv:
    def __init__(self):
        self.state = {
            "threat_level": 0
        }

    def reset(self):
        self.state["threat_level"] = 0
        return self.state

    def step(self):
        # simulate attack
        lat = random.uniform(-90, 90)
        lon = random.uniform(-180, 180)
        intensity = random.randint(1, 10)

        self.state["threat_level"] = intensity

        return {
            "location": [lat, lon],
            "intensity": intensity,
            "status": "ok"
        }
