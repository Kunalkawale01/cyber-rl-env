from fastapi import FastAPI, WebSocket
from backend.websocket import attack_stream

app = FastAPI()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await attack_stream(websocket)

@app.get("/")
def home():
    return {"message": "Cyber RL Backend Running 🚀"}
