from fastapi import WebSocket
import random
import asyncio

async def attack_stream(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = {
            "location": [random.uniform(-90, 90), random.uniform(-180, 180)],
            "intensity": random.randint(1, 10)
        }
        await websocket.send_json(data)
        await asyncio.sleep(1)
